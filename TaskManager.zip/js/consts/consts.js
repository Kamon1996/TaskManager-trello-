function getId() {
  return Math.floor(Math.random() * 9999);
}
