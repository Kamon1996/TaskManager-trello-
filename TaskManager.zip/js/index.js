const loadModule = async () => {
  await import('./components/App.js');
};

loadModule();
